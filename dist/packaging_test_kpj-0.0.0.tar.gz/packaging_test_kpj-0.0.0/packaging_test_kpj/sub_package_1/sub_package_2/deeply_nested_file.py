def deeply_nested():
    print("deeply nested response")