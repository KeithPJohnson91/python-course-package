def myfile_func():
    print("hello from my file")